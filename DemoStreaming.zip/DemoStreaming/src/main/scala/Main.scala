package org.itc.com

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger

object Main extends App {
  // Set logger level to only display errors to avoid too much log output
  Logger.getLogger("org").setLevel(Level.ERROR)

  // Spark Configuration
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name", "sparkstructureDemo")
  sparkConf.set("spark.master", "local[1]")
  sparkConf.set("spark.sql.streaming.schemaInference", "true")

  // SparkSession Initialization
  val ss = SparkSession.builder().config(sparkConf).getOrCreate()

  // Define schema for the JSON file
  val orderSchema = """
    order_id INT,
    order_date STRING,
    order_customer_id INT,
    order_status STRING,
    order_amount INT
  """

  // Load streaming data from the specified path
  val inputPath = "D:/Amazon/raw/input" // Now pointing to the directory
  val orderDF = ss.readStream
    .format("json")
    .schema(orderSchema)
    .option("path", inputPath)
    .load()

  // Create a temporary view for SQL queries
  orderDF.createOrReplaceTempView("orders")

  // Define the transformation using SQL
  val holdOrders = ss.sql("SELECT * FROM orders WHERE order_status = 'ON_HOLD'")

  // Write the output to JSON format, setting output path and checkpoint location
  val query = holdOrders.writeStream
    .format("json")
    .outputMode("append")
    .option("path", "D:/Amazon/output") // Change this path as needed
    .option("checkpointLocation", "D:/Amazon/checkpoint") // Change this path as needed
    .trigger(Trigger.ProcessingTime("30 seconds"))
    .start()

  // Await termination of the streaming query
  query.awaitTermination()
}