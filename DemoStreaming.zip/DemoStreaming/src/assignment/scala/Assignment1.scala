Assignment for today
cleaning
1. check for outlier in length and width column
2. seperate product_number into two columns storeid and productid using _ as seperator.
3. seperate year from product_name in year column.


package org.itc

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object DFDemo extends App {

  // Create a SparkConf object
  val sparkConf = new SparkConf()
  sparkConf.setAppName("DataFrameDEMO")
  sparkConf.setMaster("local[1]")

  // Create a SparkSession using the configuration
  val ss = SparkSession.builder().config(sparkConf).getOrCreate()

  // Define the schema using a DDL string (Data Definition Language)
  val ddlSchema = "product_number STRING, " +
    "product_name STRING, " +
    "product_category STRING, " +
    "product_scale STRING, " +
    "product_manufacturer STRING, " +
    "product_description STRING, " +
    "length DOUBLE, " +
    "width DOUBLE, " +
    "height DOUBLE"

  // Read the CSV file as a DataFrame using the DDL string for schema
  val productdf = ss.read
    .option("header", true)
    .schema(ddlSchema)
    .csv("file:///D:/Amazon/raw/products.csv")

  // 1. Check for outliers in 'length' and 'width' columns
  def detectOutliers(df: org.apache.spark.sql.DataFrame, columnName: String): Unit = {
    val quantiles = df.stat.approxQuantile(columnName, Array(0.25, 0.75), 0.0)
    val q1 = quantiles(0)
    val q3 = quantiles(1)
    val iqr = q3 - q1
    val lowerBound = q1 - 1.5 * iqr
    val upperBound = q3 + 1.5 * iqr

    println(s"Outliers for $columnName - Lower Bound: $lowerBound, Upper Bound: $upperBound")

    // Filter out the rows that fall below or above these bounds
    val outliersDF = df.filter(col(columnName) < lowerBound || col(columnName) > upperBound)
    outliersDF.show()
  }

  // Check for outliers in 'length' and 'width'
  detectOutliers(productdf, "length")
  detectOutliers(productdf, "width")

  // 2. Separate 'product_number' into 'storeid' and 'productid'
  val separatedDF = productdf.withColumn("storeid", split(col("product_number"), "_").getItem(0))
    .withColumn("productid", split(col("product_number"), "_").getItem(1))

  // 3. Extract 'year' from 'product_name' into a new column named 'year'
  val yearExtractedDF = separatedDF.withColumn("year", regexp_extract(col("product_name"), "(\\d{4})", 1))

  // Show the resulting DataFrame with 'storeid', 'productid', and 'year' columns
  yearExtractedDF.show(5)

  // Write the transformed DataFrame back to a CSV file
  yearExtractedDF.coalesce(1).write
    .option("header", true) // Include the header in the CSV
    .mode("overwrite") // Overwrite the existing file if it exists
    .csv("file:///D:/Amazon/staging/products_cleanedassignment.csv")

  // Stop the SparkSession
  ss.stop()
}


